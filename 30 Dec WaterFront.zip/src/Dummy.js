export const data = [
    {name: "Main saving Ampifc",
    Title: " this title ",
    Img: "img",
    Description: "this is description",
    btnName: "more info"
    },
    {name: "Main saving Ampifc",
    Title: " this title ",
    Img: "img",
    Description: "this is description",
    btnName: "more info"
    },
    {name: "Main saving Ampifc",
    Title: " this title ",
    Img: "img",
    Description: "this is description",
    btnName: "more info"
    },
    {name: "Main saving Ampifc",
    Title: " this title ",
    Img: "img",
    Description: "this is description",
    btnName: "more info"
    },
    {name: "Main saving Ampifc",
    Title: " this title ",
    Img: "img",
    Description: "this is description",
    btnName: "more info"
    },
    {name: "Main saving Ampifc",
    Title: " this title ",
    Img: "img",
    Description: "this is description",
    btnName: "more info"
    },
]