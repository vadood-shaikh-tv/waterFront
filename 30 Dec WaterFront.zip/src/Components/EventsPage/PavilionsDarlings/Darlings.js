import React from "react";

export default function Darlings() {
  return (
    <>
      <h1>hiiii</h1>
      <div>hello</div>
    </>
  );
}
